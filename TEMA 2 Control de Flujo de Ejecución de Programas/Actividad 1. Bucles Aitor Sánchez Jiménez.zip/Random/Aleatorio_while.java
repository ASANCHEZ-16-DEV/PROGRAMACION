import java.util.Random;


public class Aleatorio_while {
    public static void main(String[] args) {
  
Random nd = new Random();        

//VARIABLES Y CONSTANTES

int rnd=0;


while(rnd<10 ){ rnd++;
    
    rnd = nd.nextInt(5000);
    if(rnd % 2 == 0){
        System.out.println("El número " +rnd+ " es par");

    }else{        
        System.out.println("El número " +rnd+ " es impar");
   
    }

}


    }
}
