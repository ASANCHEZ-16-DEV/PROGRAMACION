
public class numeros_for {
    public static void main(String[] args) {

int counter = 0;  
          
for(int i=0; i<300; i++){  
    counter = counter + 1;  

if (i % 5==0){ 
System.out.println(counter);  
}



  }
 }
}
