
public class cuadrado{
    public static void main(String[] args) {
       
        int num=2;
        int resul;
        
        resul=num*num;
        System.out.println("El cuadrado es:" + resul);
        
     }    
}
          
